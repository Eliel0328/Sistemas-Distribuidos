/*
  Carlos Pineda Guerrero, Octubre 2021
*/

package negocio;

public class Foto
{
	public int id_foto;
	public byte[] foto;
}
