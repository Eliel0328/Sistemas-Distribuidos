package negocio;

public class Foto {
	public int id_foto;
	public byte[] foto;
}
